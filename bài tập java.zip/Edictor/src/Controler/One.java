package Controler;

import java.io.File;
import java.io.IOException;

import javax.swing.JOptionPane;

import View.Edictor_two;

public class One {
	Edictor_two two = new Edictor_two();

}

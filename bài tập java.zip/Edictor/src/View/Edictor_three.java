package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Model.Edictor_Model;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Edictor_three extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField Write_Text;
	private JTextField File_name;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edictor_three frame = new Edictor_three();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Edictor_three() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 759, 564);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		Write_Text = new JTextField();
		Write_Text.setBounds(53, 49, 657, 161);
		contentPane.add(Write_Text);
		Write_Text.setColumns(10);

		File_name = new JTextField();
		File_name.setBounds(222, 272, 488, 55);
		contentPane.add(File_name);
		File_name.setColumns(10);

		JLabel lblNewLabel = new JLabel("file name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(50, 277, 162, 50);
		contentPane.add(lblNewLabel);

		JButton Button_Share = new JButton("Share");
		Button_Share.addActionListener(Event -> {
			Write_File();
		});
		Button_Share.setFont(new Font("Tahoma", Font.BOLD, 20));
		Button_Share.setBounds(301, 427, 162, 50);
		contentPane.add(Button_Share);
		
		btnNewButton = new JButton("back");
		btnNewButton.addActionListener(Event -> {
			Edictor_one one = new Edictor_one();
			one.setVisible(true);
			dispose();
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(26, 478, 85, 39);
		contentPane.add(btnNewButton);
	}

	public void Write_File() {
		Edictor_Model model = new Edictor_Model();
		String fileName = model.setFile_Name(File_name.getText());
		String content = model.settext_Write(Write_Text.getText());
		if (!fileName.isEmpty()) {
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
				writer.write(content);
				JOptionPane.showMessageDialog(null, "Nội dung đã được lưu vào file thành công!");
			} catch (IOException exception) {
				JOptionPane.showMessageDialog(null, "Lỗi khi lưu file!");
				exception.printStackTrace();
			}
		} else {
			JOptionPane.showMessageDialog(null, "Vui lòng nhập tên file!");
		}
	}
}

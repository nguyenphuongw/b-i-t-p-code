package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Model.Edictor_Model;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Edictor_four extends JFrame {

	public static final long serialVersionUID = 1L;
	public JPanel contentPane;
	public JTextField File_Name;
	public JTextField Reader_Text;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edictor_four frame = new Edictor_four();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Edictor_four() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 775, 541);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		File_Name = new JTextField();
		File_Name.setBounds(68, 74, 588, 59);
		contentPane.add(File_Name);
		File_Name.setColumns(10);

		JLabel lblNewLabel = new JLabel("File Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(265, 22, 177, 42);
		contentPane.add(lblNewLabel);

		Reader_Text = new JTextField();
		Reader_Text.setBounds(56, 311, 558, 183);
		contentPane.add(Reader_Text);
		Reader_Text.setColumns(10);

		JButton Button_Reader = new JButton("Reader File");
		Button_Reader.addActionListener(Event -> {
			Read_File();
		});
		Button_Reader.setFont(new Font("Tahoma", Font.BOLD, 17));
		Button_Reader.setBounds(301, 222, 141, 59);
		contentPane.add(Button_Reader);

		btnNewButton = new JButton("back");
		btnNewButton.addActionListener(Event -> {
			Edictor_one one = new Edictor_one();
			one.setVisible(true);
			dispose();
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(666, 455, 85, 39);
		contentPane.add(btnNewButton);
	}

	public void Read_File() {
		Edictor_Model model = new Edictor_Model();
		String fileName = model.setText_Read(File_Name.getText());
		if (!fileName.isEmpty()) {
			try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
				StringBuilder content = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					content.append(line).append("\n");
				}
				Reader_Text.setText(content.toString());
			} catch (IOException exception) {
				JOptionPane.showMessageDialog(null, "Lỗi khi đọc file!");
				exception.printStackTrace();
			}
		} else {
			JOptionPane.showMessageDialog(null, "Vui lòng nhập tên file!");
		}
	}

}

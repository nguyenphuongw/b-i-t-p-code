package View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Edictor_one extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Edictor_one frame = new Edictor_one();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Edictor_one() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 745, 455);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Creater file");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.addActionListener(Event -> {
			    Edictor_two two = new Edictor_two();
			    two.setVisible(true);
			    dispose();
		});
//			public void actionPerformed(ActionEvent e) {
//				
//			}
//		});
		btnNewButton.setBounds(83, 188, 133, 34);
		contentPane.add(btnNewButton);
		
		JButton btnReadFile = new JButton("read file");
		btnReadFile.addActionListener(Event -> {
			Edictor_four four = new Edictor_four();
			four.setVisible(true);
			dispose();
		});
		btnReadFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnReadFile.setBounds(260, 188, 133, 34);
		contentPane.add(btnReadFile);
		
		JButton btnWriteFile = new JButton("write file");
		btnWriteFile.addActionListener(Event -> {
			Edictor_three three = new Edictor_three();
			three.setVisible(true);
			dispose();
		});
		btnWriteFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnWriteFile.setBounds(444, 188, 133, 34);
		contentPane.add(btnWriteFile);
	}

}

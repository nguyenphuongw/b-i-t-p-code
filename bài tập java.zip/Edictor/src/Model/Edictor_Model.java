package Model;

public class Edictor_Model {
	public String Text_Write;
	public String File_Name;
	public String Text_Read;

	public Edictor_Model(String text_Write, String file_Name, String text_Read) {
		super();
		Text_Write = text_Write;
		File_Name = file_Name;
		Text_Read = text_Read;
	}

	public Edictor_Model() {
		super();
	}

	public String getFile_Name() {
		return File_Name;
	}
	

	public String getText_Write() {
		return Text_Write;
	}

	public String settext_Write(String text_Write) {
		return Text_Write = text_Write;
	}

	public String getText_Read() {
		return Text_Read;
	}

	public String setText_Read(String text_Read) {
		return Text_Read = text_Read;
	}

	public String setFile_Name(String file_Name) {
		return File_Name = file_Name;
	}

	public String setText_Write(String text) {
		// TODO Auto-generated method stub
		return null;
	}
}
